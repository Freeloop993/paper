from pathlib import Path
import json,hashlib
from PIL import Image,ImageChops,ImageStat,ImageDraw
base=Path.cwd(); old=base.parent/'takeover-v2'; new=base/'hexa'
assert (base/'transition.json').is_file()
tr=json.loads((base/'transition.json').read_bytes()); rows=json.loads((base/'experiments/gpu-day-20261115/hexa-fix/manifest.json').read_bytes())['requests']; hist={x['id']:x for x in tr['old_hexa_completed']}; actual={x['id']:x for x in map(json.loads,(new/'progress.jsonl').read_bytes().splitlines())}; pairs=[]; canvas=Image.new('RGB',(1280,1430),'white'); draw=ImageDraw.Draw(canvas)
for r in rows:
 a,b=r['replaces'],r['id']
 if a not in hist: continue
 assert b in actual
 op=old/a;np=new/b
 oo=json.loads((op/'request.json').read_bytes())['prompt']; nn=json.loads((np/'request.json').read_bytes())['prompt']; orig=oo['4']['inputs']['negative_prompt']; correct=nn['4']['inputs']['negative_prompt']; assert orig!=correct
 oo['4']['inputs']['negative_prompt']=correct;oo['12']['inputs']['filename_prefix']=b;assert oo==nn
 x=(op/(a+'.png')).read_bytes();y=(np/(b+'.png')).read_bytes();assert hashlib.sha256(x).hexdigest()==hist[a]['png_sha256'] and hashlib.sha256(y).hexdigest()==actual[b]['png_sha256'];
 with Image.open(op/(a+'.png')) as ix,Image.open(np/(b+'.png')) as iy:
  ix,iy=ix.convert('RGB'),iy.convert('RGB');assert ix.size==iy.size==(1024,1024)
  delta=ImageChops.difference(ix,iy); ident=delta.getbbox() is None
  if len(pairs)<3:
   for j,img in enumerate((ix,iy)):
    px=5+len(pairs)*424;py=35+460*j;canvas.paste(img.resize((408,408),Image.Resampling.LANCZOS),(px,py));draw.text((px,py+410),(a,b)[j],fill='black')
 pairs.append({'old':a,'corrected':b,'seed':r['seed'],'old_png_sha256':hist[a]['png_sha256'],'corrected_png_sha256':actual[b]['png_sha256'],'decoded_rgb_identical':ident})
assert len(pairs)==15
out={'purpose':'15 matched historical/corrected pairs; implementation check only, no perceptual ratings','accounting':'The 15 historical observations do not enter corrected denominators.','changed_fields':['TextEncodeQwenImage21.negative_prompt','SaveImage.filename_prefix'],'pairs':pairs,'decoded_rgb_different':sum(not x['decoded_rgb_identical'] for x in pairs)}
(base/'paired-check.json').write_text(json.dumps(out,indent=2));canvas.crop((0,0,1280,936)).save(base/'paired-drafts.jpg',quality=92);print('checked',len(pairs),'RGB differs',out['decoded_rgb_different'])
