import pandas as pd

# 读取共词矩阵
df = pd.read_csv(r'd:\桌面\新建文件夹 (2)\共词矩阵.csv', encoding='gbk', index_col=0)

# 去除全为空的行和列
df = df.dropna(how='all', axis=0).dropna(how='all', axis=1)

# 将所有数据转为数值型，非数值填0
df = df.apply(pd.to_numeric, errors='coerce').fillna(0)

# 生成边列表
edges = []
for i, source in enumerate(df.index):
    for j, target in enumerate(df.columns):
        weight = df.iloc[i, j]
        if i < j and weight > 0:  # 只保留上三角，避免重复和自环
            edges.append([source, target, int(weight)])

# 保存为Gephi可用的边列表CSV
edges_df = pd.DataFrame(edges, columns=['Source', 'Target', 'Weight'])
edges_df.to_csv(r'd:\桌面\新建文件夹 (2)\共词边列表.csv', index=False, encoding='utf-8-sig')
print("边列表已生成：d:\\桌面\\新建文件夹 (2)\\共词边列表.csv")