import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib

matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

# 读取共词矩阵
df = pd.read_csv(r'd:\桌面\新建文件夹 (2)\共词矩阵.csv', encoding='gbk', index_col=0)
df = df.dropna(how='all', axis=0).dropna(how='all', axis=1)
df = df.apply(pd.to_numeric, errors='coerce').fillna(0)

# 计算每个词的总共现次数，选取前5个高频词
top_n = 5
top_words = df.sum(axis=1).sort_values(ascending=False).head(top_n).index.tolist()

# 以这5个词为主，统计它们与其他top词的共现次数
data = df.loc[top_words, top_words]

# 雷达图准备
labels = list(data.columns)
num_vars = len(labels)

angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
angles += angles[:1]  # 闭合

plt.figure(figsize=(8, 8))
for idx, row in data.iterrows():
    values = row.tolist()
    values += values[:1]  # 闭合
    plt.polar(angles, values, label=idx, linewidth=2)

plt.xticks(angles[:-1], labels, fontsize=12)
plt.title("高频关键词共现分布雷达图", fontsize=18)
plt.legend(loc='upper right', bbox_to_anchor=(1.2, 1.05))
plt.tight_layout()
plt.savefig(r'd:\桌面\新建文件夹 (2)\共词雷达图.png', dpi=300)
plt.show()