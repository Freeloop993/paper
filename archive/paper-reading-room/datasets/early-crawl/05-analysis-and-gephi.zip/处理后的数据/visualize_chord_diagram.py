import pandas as pd
import plotly.graph_objects as go

# 读取共词矩阵
df = pd.read_csv(r'd:\桌面\新建文件夹 (2)\共词矩阵.csv', encoding='gbk', index_col=0)
df = df.dropna(how='all', axis=0).dropna(how='all', axis=1)
df = df.apply(pd.to_numeric, errors='coerce').fillna(0)

# 选取前10个高频词
top_n = 10
top_words = df.sum(axis=1).sort_values(ascending=False).head(top_n).index.tolist()
data = df.loc[top_words, top_words]

# 分层：前2个为核心词，后8个为属性词
core_n = 2
core_words = top_words[:core_n]
attr_words = top_words[core_n:]
labels = core_words + attr_words

# 构建桑基图数据，只显示核心词到属性词的连接
source = []
target = []
value = []
for i, src in enumerate(core_words):
    for j, tgt in enumerate(attr_words):
        weight = data.loc[src, tgt]
        if weight > 0:
            source.append(labels.index(src))
            target.append(labels.index(tgt))
            value.append(weight)

# 节点颜色分层
node_colors = ['#1f77b4'] * len(core_words) + ['#2ca02c'] * len(attr_words)

fig = go.Figure(data=[go.Sankey(
    node=dict(
        pad=20,
        thickness=30,
        line=dict(color="black", width=0.5),
        label=labels,
        color=node_colors
    ),
    link=dict(
        source=source,
        target=target,
        value=value,
        color="rgba(44, 160, 101, 0.3)"
    )
)])

fig.update_layout(
    title_text="高频词对感性共现桑基图（分层优化）",
    font=dict(family="SimHei,Microsoft YaHei", size=16),
    width=900,
    height=600,
    margin=dict(l=40, r=40, t=80, b=40)
)

fig.write_html(r'd:\桌面\新建文件夹 (2)\共词桑基图_分层优化版.html', include_plotlyjs='cdn')
fig.show()