import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import matplotlib
from networkx.algorithms import community

matplotlib.rcParams['font.sans-serif'] = ['SimHei']
matplotlib.rcParams['axes.unicode_minus'] = False

# 读取边列表
edges_df = pd.read_csv(r'd:\桌面\新建文件夹 (2)\共词边列表.csv', encoding='utf-8-sig')

# 构建无向图
G = nx.Graph()
for _, row in edges_df.iterrows():
    G.add_edge(row['Source'], row['Target'], weight=row['Weight'])

# 社区发现（Louvain算法，需安装python-louvain库）
try:
    import community as community_louvain
    partition = community_louvain.best_partition(G)
    # 按社区分配颜色
    communities = set(partition.values())
    color_map = plt.cm.get_cmap('tab20', len(communities))
    node_colors = [color_map(partition[node]) for node in G.nodes()]
except ImportError:
    # 如果没有louvain库，则全部用同色
    node_colors = 'skyblue'

# 节点大小与度数相关，边宽与权重相关
node_strength = dict(G.degree(weight='weight'))
node_sizes = [node_strength[n] * 30 for n in G.nodes()]
edge_widths = [d['weight'] / 10 for u, v, d in G.edges(data=True)]

plt.figure(figsize=(20, 16))
pos = nx.spring_layout(G, k=0.6, seed=42)

# 绘制节点和边
nx.draw_networkx_nodes(G, pos, node_size=node_sizes, node_color=node_colors, alpha=0.85)
nx.draw_networkx_edges(G, pos, width=edge_widths, alpha=0.4, edge_color='#888888')

# 只显示高权重节点标签
labels = {}
for node in G.nodes():
    if node_strength[node] >= sorted(node_strength.values(), reverse=True)[max(5, len(node_strength)//20)]:
        labels[node] = node
nx.draw_networkx_labels(G, pos, labels, font_size=12, font_weight='bold')

plt.title("共词知识网络图谱（工业设计主题）", fontsize=22, fontweight='bold')
plt.axis('off')
plt.tight_layout()
plt.savefig(r'd:\桌面\新建文件夹 (2)\共词网络图_优化版.png', dpi=300)
plt.show()