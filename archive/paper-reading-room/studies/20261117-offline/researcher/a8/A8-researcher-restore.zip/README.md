# A8 私有读图包恢复

此小包供保管对应键的研究者跨机复原既有的空白包。只给每位盲读者其自己的 AI、H1 或 H2 目录。本包、对应键与图源表由组织者保管。

原图库为私有 GitHub 仓库 Freeloop993/paper。已在原始 PNG 或 ZIP 成员一级对照 SHA-256；github-sources.csv 逐图记录固定提交、路径、Git blob、ZIP 内成员及解码 RGB 摘要。AI 含 64 个案例和 4 张条件图，H1/H2 各含同样 20 个案例及 4 张条件图。三个编号表与回件顺序均保留。

在可读取原图库的机器上解压此包，在解压目录运行。若已有 paper 本地仓库，可以省略 clone 步骤。

```sh
git clone --filter=blob:none --no-checkout --depth=1 https://github.com/Freeloop993/paper.git paper
git -C paper fetch --depth=1 origin e96d41946ea84237da506bb76c2f713a3f3b9275 5f92248dd353075d83134c99c7d52383b96a6a48
python -m pip install Pillow==11.2.1
python restore.py paper ../A8-private
```

恢复目录须为新目录。原包由 Python 3.11.9 和 Pillow 11.2.1 生成。程序核验 PNG 原字节、RGB 及全部 123 个恢复文件的 SHA-256，全部通过后才生成最终目录。若 PNG 编码库导致字节变化，请在相同版本环境重做，保留原有编号。

本包自带空白答卷、原说明与程序，不含匿名图片。GitHub 原图已经存在；此次研究者恢复包未提交远端。
