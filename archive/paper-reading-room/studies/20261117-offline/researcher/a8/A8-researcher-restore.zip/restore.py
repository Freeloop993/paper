"""Restore this exact A8 blank packet from a researcher's handoff and verified Git blobs."""
import argparse
import csv
import hashlib
import io
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path

from PIL import Image

KIT = Path(__file__).resolve().parent
READERS = ("AI", "H1", "H2")


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def sha(data):
    return hashlib.sha256(data).hexdigest()


def restore(repo, destination):
    if destination.exists():
        raise SystemExit("Choose a new destination.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    sources = read_csv(KIT / "github-sources.csv")
    key = read_csv(KIT / "PRIVATE-key.csv")
    inventory = {r["path"]: r["sha256"] for r in read_csv(KIT / "packet-sha256.csv")}
    blobs = {}
    with tempfile.TemporaryDirectory(dir=destination.parent) as scratch:
        stage = Path(scratch) / "packet"
        stage.mkdir()
        shutil.copyfile(KIT / "PRIVATE-key.csv", stage / "PRIVATE-key.csv")
        for reader in READERS:
            shutil.copytree(KIT / reader, stage / reader)
        for row in sources:
            oid = row["git_blob_sha1"]
            if oid not in blobs:
                raw = subprocess.check_output(["git", "-C", str(repo), "cat-file", "blob", oid])
                header = b"blob " + str(len(raw)).encode() + b"\0"
                if hashlib.sha1(header + raw).hexdigest() != oid:
                    raise ValueError("Git blob mismatch: " + oid)
                blobs[oid] = raw
            data = blobs[oid]
            if row["zip_member"]:
                with zipfile.ZipFile(io.BytesIO(data)) as archive:
                    data = archive.read(row["zip_member"])
            if sha(data) != row["sha256"]:
                raise ValueError("Original hash mismatch: " + row["original"])
            with Image.open(io.BytesIO(data)) as image:
                im = image.convert("RGB")
                im.info.clear()
                if sha(im.tobytes()) != row["rgb_sha256"]:
                    raise ValueError("RGB mismatch: " + row["original"])
                for entry in key:
                    if entry["file"] == row["original"]:
                        im.save(stage / entry["reader"] / (entry["token"] + ".png"))
        actual = {p.relative_to(stage).as_posix(): sha(p.read_bytes()) for p in stage.rglob("*") if p.is_file()}
        if actual != inventory:
            raise ValueError("Packet bytes differ; check Pillow 11.2.1 and the PNG/zlib runtime.")
        stage.rename(destination)
    print("Restored and verified", len(actual), "files.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path, help="Local clone of Freeloop993/paper containing the two source commits")
    parser.add_argument("destination", type=Path, help="New private packet directory")
    args = parser.parse_args()
    restore(args.repo, args.destination.resolve())

